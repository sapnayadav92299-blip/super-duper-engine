package dev.lelonio.square.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.lelonio.square.R
import dev.lelonio.square.SquareApplication

/**
 * Connecting to ListenBrainz: the user token from the site's settings page, and
 * where the listens stand.
 *
 * Kept in a field that hides what is typed, because a token is a password, and
 * shown afterwards only by its last four characters.
 */
@Composable
internal fun ListenBrainzSetup() {
    val context = LocalContext.current
    val brainz = remember(context) { (context.applicationContext as SquareApplication).listenBrainz }
    val token by brainz.token.collectAsStateWithLifecycle()
    val pending by brainz.pending.collectAsStateWithLifecycle()
    val rejected by brainz.rejected.collectAsStateWithLifecycle()
    var draft by rememberSaveable { mutableStateOf("") }

    Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
        Text(
            stringResource(R.string.scrobble_explainer),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (token.isEmpty()) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it.trim() },
                label = { Text(stringResource(R.string.scrobble_token)) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
            )
            TextButton(
                onClick = {
                    brainz.setToken(draft)
                    draft = ""
                },
                enabled = draft.length >= 8,
                modifier = Modifier.padding(top = 8.dp),
            ) {
                Text(stringResource(R.string.connect))
            }
        } else {
            Text(
                stringResource(R.string.scrobble_connected, token.takeLast(4)),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 16.dp),
            )
            val state = when {
                rejected -> stringResource(R.string.scrobble_rejected)
                pending > 0 -> stringResource(R.string.scrobble_pending, pending)
                else -> stringResource(R.string.scrobble_ready)
            }
            Text(
                state,
                style = MaterialTheme.typography.bodySmall,
                color = if (rejected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
            TextButton(
                onClick = { brainz.setToken("") },
                modifier = Modifier.padding(top = 8.dp),
            ) {
                Text(stringResource(R.string.disconnect))
            }
        }
    }
}
