package dev.lelonio.square.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * What a long press on a lyric line does: hands the line's text over. Provided
 * by the player around its lyrics; absent everywhere else, where a long press
 * on a line does nothing.
 */
val LocalLyricLongPress = staticCompositionLocalOf<((String) -> Unit)?> { null }

/**
 * A card with one line of a song's lyrics on it, over its own cover blurred to
 * a wash of its colours, handed to the share sheet.
 *
 * Drawn straight to a bitmap, like the song card, so what is shared is the same
 * picture whatever the screen was doing.
 */
suspend fun shareLyricCard(context: Context, line: String, title: String, artist: String, artworkUrl: String?) {
    val text = line.trim()
    if (text.isEmpty()) return
    val file = withContext(Dispatchers.Default) {
        runCatching { buildLyricCard(context, text, title, artist, artworkUrl) }.getOrNull()
    } ?: return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.reports", file)
    val send = Intent(Intent.ACTION_SEND)
        .setType("image/png")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    startShareSheet(context, send)
}

private suspend fun buildLyricCard(
    context: Context,
    line: String,
    title: String,
    artist: String,
    artworkUrl: String?,
): File {
    val w = 1080
    val h = 1920
    val cover: Bitmap? = artworkUrl?.let { url ->
        val result = context.imageLoader.execute(
            ImageRequest.Builder(context).data(url).allowHardware(false).size(900).build(),
        )
        (result as? SuccessResult)?.drawable?.toBitmap(900, 900)
    }
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(bmp)

    // The ground: the cover shrunk to a handful of pixels and stretched back,
    // which is a soft wash of its own colours, under a dark veil.
    if (cover != null) {
        val wash = Bitmap.createScaledBitmap(cover, 16, 16, true)
        c.drawBitmap(wash, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
    } else {
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply { color = 0xFF16161A.toInt() })
    }
    val veil = Paint(Paint.ANTI_ALIAS_FLAG)
    veil.shader = LinearGradient(
        0f, 0f, 0f, h.toFloat(),
        intArrayOf(0xB3000000.toInt(), 0xCC000000.toInt(), 0xF2000000.toInt()),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP,
    )
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), veil)

    // The song, small, at the top: its cover and the names beside it.
    val side = 200f
    val left = 90f
    val top = 170f
    if (cover != null) {
        val clip = Path().apply { addRoundRect(RectF(left, top, left + side, top + side), 30f, 30f, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        c.drawBitmap(cover, null, RectF(left, top, left + side, top + side), Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
    }
    val textLeft = if (cover != null) left + side + 40f else left
    val textWidth = (w - 90f - textLeft).toInt()
    val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 50f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, textWidth)
        .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
    val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB9BBC2.toInt(); textSize = 38f
    }
    val artistLayout = StaticLayout.Builder.obtain(artist, 0, artist.length, artistPaint, textWidth)
        .setMaxLines(1).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
    val blockHeight = titleLayout.height + 14f + artistLayout.height
    c.save()
    c.translate(textLeft, top + (side - blockHeight) / 2f)
    titleLayout.draw(c)
    c.translate(0f, titleLayout.height + 14f)
    artistLayout.draw(c)
    c.restore()

    // The line: large, white, left-aligned, sized to how much of it there is.
    val size = when {
        line.length <= 40 -> 96f
        line.length <= 90 -> 76f
        else -> 60f
    }
    val quote = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x55FFFFFF; textSize = 260f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }
    c.drawText("\u201C", 80f, 640f, quote)
    val linePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = size; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    val lineLayout = StaticLayout.Builder.obtain(line, 0, line.length, linePaint, w - 180)
        .setMaxLines(9).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL)
        .setLineSpacing(0f, 1.12f).build()
    c.save()
    c.translate(90f, 700f)
    lineLayout.draw(c)
    c.restore()

    // The maker's mark.
    val mark = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFD2D4DA.toInt(); textSize = 34f; letterSpacing = 0.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.CENTER
    }
    c.drawText("TITOPLAY", w / 2f, h - 130f, mark)

    val dir = File(context.cacheDir, "cards").apply { mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    val out = File(dir, "titoplay-lyric.png")
    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return out
}
