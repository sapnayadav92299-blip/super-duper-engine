package dev.lelonio.square.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import dev.lelonio.square.playback.AudioRoute
import dev.lelonio.square.playback.ChannelBalance

/** True while the music is going to headphones or earbuds (cable, Bluetooth, USB). */
@Composable
fun rememberHeadphonesConnected(): Boolean {
    val output by AudioRoute.current.collectAsState()
    return ChannelBalance.isHeadphones(output.kind)
}

/**
 * One earbud's volume: drag up or down along one edge of the cover to set that
 * side alone.
 *
 * Nothing is drawn while the edge is left alone. Under a finger a panel comes up
 * beside it, inboard of the thumb so the thumb does not hide it, with the level
 * as a number and as a bar, and the earbud it belongs to; a moment after the
 * finger lifts it goes again. The picture is `bud_left.jpg` / `bud_right.jpg` if
 * the app has them in its drawables, a drawn earbud otherwise.
 *
 * Fills the space it is given, only to have room to draw in: what answers to
 * touch is the strip at the edge, as it always was, and the rest lets every
 * touch through to the cover.
 */
@Composable
fun BudVolumeStrip(right: Boolean, modifier: Modifier = Modifier) {
    val view = LocalView.current
    val level = if (right) ChannelBalance.right.floatValue else ChannelBalance.left.floatValue

    // Held while a finger is down, and for a short moment each side of it: a
    // tap or a swipe across the edge is over before the panel would have come
    // up, so it never flashes, and after a lift the number stays long enough to read.
    var touching by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(touching) {
        if (touching) {
            delay(SHOW_AFTER_MS)
            shown = true
        } else {
            delay(HIDE_AFTER_MS)
            shown = false
        }
    }
    val visibility by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(if (shown) 140 else 320, easing = FastOutSlowInEasing),
        label = "bud-volume-visibility",
    )

    androidx.compose.foundation.layout.BoxWithConstraints(modifier.fillMaxSize()) {
        val edge = if (right) Alignment.CenterEnd else Alignment.CenterStart
        // The panel is about 260 dp at full size; where the page gives less, the bar gives up the difference.
        val barHeight = (maxHeight - 96.dp).coerceIn(80.dp, 176.dp)

        Box(
            Modifier
                .align(edge)
                .fillMaxHeight(0.5f)
                .width(64.dp)
                .pointerInput(right) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        touching = true
                        try {
                            var current = if (right) ChannelBalance.right.floatValue else ChannelBalance.left.floatValue
                            val travel = (size.height * 0.6f).coerceAtLeast(1f)

                            fun move(dy: Float) {
                                val next = (current - dy / travel).coerceIn(0f, 1f)
                                if (kotlin.math.round(next * 20f) != kotlin.math.round(current * 20f)) {
                                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                }
                                current = next
                                if (right) ChannelBalance.set(null, next) else ChannelBalance.set(next, null)
                            }

                            val slop = awaitVerticalTouchSlopOrCancellation(down.id) { change, overSlop ->
                                change.consume()
                                move(overSlop)
                            }
                            if (slop != null) {
                                verticalDrag(slop.id) { change ->
                                    change.consume()
                                    move(change.positionChange().y)
                                }
                            }
                        } finally {
                            touching = false
                        }
                    }
                },
        )

        if (visibility > 0.001f) {
            BudVolumePanel(
                right = right,
                level = level,
                barHeight = barHeight,
                modifier = Modifier
                    .align(edge)
                    // Past the thumb: the strip is the 64 dp at the edge.
                    .padding(start = if (right) 0.dp else 72.dp, end = if (right) 72.dp else 0.dp)
                    .graphicsLayer {
                        alpha = visibility
                        val settle = 0.94f + 0.06f * visibility
                        scaleX = settle
                        scaleY = settle
                    },
            )
        }
    }
}

/** The panel itself: the number, the bar, and which earbud. */
@Composable
private fun BudVolumePanel(
    right: Boolean,
    level: Float,
    barHeight: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
) {
    val shown = level.coerceIn(0f, 1f)
    val percent = kotlin.math.round(shown * 100f).toInt()
    val glass = Color.Black.copy(alpha = 0.58f)
    val rim = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f))

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(glass)
                .border(rim, RoundedCornerShape(14.dp))
                .width(60.dp)
                .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center,
        ) {
            androidx.compose.material3.Text(
                text = "$percent%",
                color = Color.White,
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    // Digits of one width, so the number does not shiver as it counts.
                    fontFeatureSettings = "tnum",
                ),
                maxLines = 1,
            )
        }
        Spacer(Modifier.height(8.dp))

        Box(
            Modifier
                .width(46.dp)
                .height(barHeight)
                .clip(RoundedCornerShape(23.dp))
                .background(glass)
                .border(rim, RoundedCornerShape(23.dp)),
            contentAlignment = Alignment.BottomCenter,
        ) {
            if (shown > 0f) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(shown.coerceAtLeast(0.04f))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = 0.98f), Color.White.copy(alpha = 0.78f)),
                            ),
                        ),
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        Row(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(glass)
                .border(rim, RoundedCornerShape(14.dp))
                .padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            BudGlyph(right = right, size = 22.dp)
            androidx.compose.material3.Text(
                text = if (right) "R" else "L",
                color = Color.White.copy(alpha = 0.9f),
                style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
            )
        }
    }
}

/** The earbud: the app's own picture if it has one, a drawn one if not. */
@Composable
private fun BudGlyph(right: Boolean, size: androidx.compose.ui.unit.Dp) {
    val context = LocalContext.current
    val resId = remember(right) {
        context.resources.getIdentifier(if (right) "bud_right" else "bud_left", "drawable", context.packageName)
    }
    if (resId != 0) {
        Image(
            painter = painterResource(resId),
            contentDescription = null,
            modifier = Modifier.size(size).clip(RoundedCornerShape(size * 0.26f)),
            contentScale = ContentScale.Fit,
        )
    } else {
        Canvas(Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val ink = Color.White.copy(alpha = 0.92f)
            drawCircle(ink, radius = w * 0.27f, center = Offset(if (right) w * 0.42f else w * 0.58f, h * 0.30f))
            drawRoundRect(
                ink,
                topLeft = Offset(if (right) w * 0.52f else w * 0.30f, h * 0.30f),
                size = Size(w * 0.18f, h * 0.62f),
                cornerRadius = CornerRadius(w * 0.09f, w * 0.09f),
            )
        }
    }
}

/** How long a finger rests before the panel comes up, and how long it stays after the lift. */
private const val SHOW_AFTER_MS = 120L
private const val HIDE_AFTER_MS = 650L
