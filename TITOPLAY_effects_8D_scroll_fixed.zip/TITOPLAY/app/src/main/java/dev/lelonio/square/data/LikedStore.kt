package dev.lelonio.square.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Tracks the listener has liked ("Tus me gusta").
 *
 * Persisted on this device and updated whenever a heart is added or removed,
 * so the notification, the lock screen and the player share one state without
 * waiting on a network round-trip.
 */
class LikedStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val saveLock = Mutex()

    private val _liked = MutableStateFlow(load())
    val likedTracks: StateFlow<Set<String>> = _liked.asStateFlow()

    fun isLiked(uri: String?): Boolean = uri != null && uri in _liked.value

    fun seed(uris: Collection<String>) {
        if (uris.isEmpty()) return
        val updated = _liked.value + uris
        if (updated.size != _liked.value.size) {
            _liked.value = updated
            save(updated)
        }
    }

    /**
     * The whole set for one source, as that source has it now: the songs under
     * [prefix] become exactly [uris], and the other source's are left alone.
     * Unlike [seed] this also takes back a heart removed somewhere else.
     */
    fun replaceSource(prefix: String, uris: Collection<String>) {
        val updated = _liked.value.filterNot { it.startsWith(prefix) }.toSet() + uris.filter { it.startsWith(prefix) }
        if (updated != _liked.value) {
            _liked.value = updated
            save(updated)
        }
    }

    fun add(uri: String) {
        if (uri in _liked.value) return
        val updated = _liked.value + uri
        _liked.value = updated
        save(updated)
    }

    fun remove(uri: String) {
        if (uri !in _liked.value) return
        val updated = _liked.value - uri
        _liked.value = updated
        save(updated)
    }

    /**
     * A heart flipped from outside the app's own screens (the notification, the
     * lock screen, the car), carrying what the song is called so the Liked Songs
     * list can be brought up to date without looking it up.
     */
    class Toggled(
        val uri: String,
        val liked: Boolean,
        val title: String,
        val artist: String,
        val artworkUrl: String?,
    )

    private val _toggled = kotlinx.coroutines.flow.MutableSharedFlow<Toggled>(extraBufferCapacity = 16)
    val toggled: kotlinx.coroutines.flow.SharedFlow<Toggled> = _toggled

    /**
     * Flips the heart. With [title] given the flip is announced on [toggled], so
     * the Liked Songs list follows it; the app's own screens look after their
     * list themselves and pass nothing.
     */
    fun toggle(uri: String, title: String? = null, artist: String? = null, artworkUrl: String? = null): Boolean {
        val nowLiked = uri !in _liked.value
        if (nowLiked) add(uri) else remove(uri)
        if (title != null) _toggled.tryEmit(Toggled(uri, nowLiked, title, artist.orEmpty(), artworkUrl))
        return nowLiked
    }

    private fun load(): Set<String> =
        prefs.getStringSet(KEY_LIKED, null)?.toSet() ?: emptySet()

    private fun save(tracks: Set<String>) {
        val snapshot = tracks.toSet()
        scope.launch {
            saveLock.withLock {
                prefs.edit().putStringSet(KEY_LIKED, snapshot).apply()
            }
        }
    }

    private companion object {
        const val FILE_NAME = "square_liked_tracks"
        const val KEY_LIKED = "liked_tracks"
    }
}
