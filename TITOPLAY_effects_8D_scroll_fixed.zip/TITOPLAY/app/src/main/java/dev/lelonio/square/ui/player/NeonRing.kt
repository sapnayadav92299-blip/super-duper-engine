package dev.lelonio.square.ui.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import dev.lelonio.square.playback.AudioPulse
import kotlin.math.exp
import kotlin.math.pow

/**
 * A neon light that runs round the edge of the pill while music plays.
 *
 * Built like a real neon tube rather than a coloured line: a thin, crisp tube of
 * colour with a hotter, nearly white centre, and round it two soft layers of glow
 * that add their light to whatever is behind (so it shines instead of tinting),
 * the widest of them spilling outside the pill's edge. The colour is a flowing
 * run of the palette (blue, violet, pink, amber, green, cyan, and round again)
 * that slides along all the time, so any one stretch of the light is changing
 * colour as it goes. Behind a bright head, a small flare of its own, the tube
 * thins and fades smoothly over its length, with no step anywhere in it: it is
 * laid down in short pieces along the outline, close enough together to read as
 * one unbroken curve.
 *
 * There are two, half a lap apart and in different parts of the palette: two
 * thin lines with dark edge between them, so the pill is never lit on one side only.
 *
 * The music drives all of it: the lights run round faster as the sound gets
 * stronger and are thrown forward on every beat of the bass; their tails
 * lengthen, the glow swells and the tube swells a little with each beat; and the
 * colours run through the palette quicker. See [AudioPulse] for where the beat
 * comes from.
 *
 * It follows the outline at an even speed (not an angle from the middle), takes no
 * touches, and when the music stops it fades out and its frame loop stops with
 * it, so a paused player costs nothing.
 *
 * Drawn on the edge and past it, so it has to be put outside anything that clips
 * to the pill's own bounds.
 */
@Composable
fun Modifier.neonRing(active: Boolean): Modifier {
    var lap by remember { mutableFloatStateOf(0f) }
    var hue by remember { mutableFloatStateOf(0f) }
    var glow by remember { mutableFloatStateOf(0f) }
    var reach by remember { mutableFloatStateOf(0f) }
    var pulse by remember { mutableFloatStateOf(0f) }
    val appear by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(450),
        label = "neon-appear",
    )

    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = 0L
        var speed = BASE_LAPS
        var drift = BASE_DRIFT
        while (true) {
            val frame = withFrameNanos { it }
            val dt = if (last == 0L) 0f else ((frame - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = frame

            val level = AudioPulse.level()
            val kick = AudioPulse.kick()

            // Laps a second: brisk even when the music is soft, fast when it is
            // strong, and thrown forward on a beat. Eased, so a change is felt
            // as a surge and never as a jump.
            val wanted = BASE_LAPS + LEVEL_LAPS * level + KICK_LAPS * kick
            speed += (wanted - speed) * (1f - exp(-dt * 9f))
            lap = (lap + speed * dt) % 1f

            // Runs of the palette a second: the colours are always on the move.
            val drifting = BASE_DRIFT + LEVEL_DRIFT * level + KICK_DRIFT * kick
            drift += (drifting - drift) * (1f - exp(-dt * 6f))
            hue = (hue + drift * dt) % 1f

            val light = (0.45f + 0.55f * level + 0.5f * kick).coerceAtMost(1f)
            glow += (light - glow) * (1f - exp(-dt * 12f))
            val length = (0.45f * level + kick).coerceAtMost(1f)
            reach += (length - reach) * (1f - exp(-dt * 8f))
            // The beat itself, quicker to rise than to fall: what swells the tube.
            pulse += (kick - pulse) * (1f - exp(-dt * (if (kick > pulse) 30f else 10f)))
        }
    }

    return this.drawWithCache {
        val w = size.width
        val h = size.height
        val radius = h / 2f
        // On the edge itself: half of the line is outside the pill.
        val outline = Path().apply {
            addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(radius, radius)))
        }
        val measure = PathMeasure().also { it.setPath(outline, true) }
        val perimeter = measure.length
        val core = CORE.toPx()

        // Where the pieces of one light are, worked out once and used by every layer.
        val xs = FloatArray(PIECES + 1)
        val ys = FloatArray(PIECES + 1)

        onDrawWithContent {
            drawContent()
            if (appear <= 0.01f || perimeter <= 0f || radius <= 0f) return@onDrawWithContent

            val strength = appear * (0.78f + 0.22f * glow)
            // Short enough that the two lights are two lines with the dark edge
            // between them: even at their longest they do not meet.
            val tail = perimeter * (0.22f + 0.13f * reach)
            val head = lap * perimeter
            val swell = 1f + 0.35f * pulse

            tube(measure, perimeter, head, tail, core * swell, strength, hue, xs, ys)
            tube(measure, perimeter, (head + perimeter / 2f) % perimeter, tail, core * swell, strength, hue + 0.5f, xs, ys)
        }
    }
}

/**
 * One light along the outline, measured by [measure]: a head at [head] (a distance
 * from the start of the outline) and, behind it, [tail] of tube that thins and
 * fades away, its colour [colourAt] at the head and moving along the palette
 * towards the tail. [xs] and [ys] are working space of [PIECES] + 1 points.
 */
private fun DrawScope.tube(
    measure: PathMeasure,
    perimeter: Float,
    head: Float,
    tail: Float,
    core: Float,
    strength: Float,
    colourAt: Float,
    xs: FloatArray,
    ys: FloatArray,
) {
    // Points along the tube, from the head back to the tail.
    for (i in 0..PIECES) {
        val distance = ((head - tail * i / PIECES) % perimeter + perimeter) % perimeter
        val at = measure.getPosition(distance)
        xs[i] = at.x
        ys[i] = at.y
    }

    // Widest and faintest first, so what is brightest is on top of it.
    // The outer glow, spilling past the edge: coarse pieces are enough at this width.
    var i = 0
    while (i < PIECES) {
        val j = minOf(i + 2, PIECES)
        val u = (i + 1) / PIECES.toFloat()
        val alpha = ((1f - u).pow(1.4f) * strength * 0.16f).coerceIn(0f, 1f)
        if (alpha > 0.01f) {
            drawLine(
                color = palette(colourAt + u * SPREAD).copy(alpha = alpha),
                start = Offset(xs[i], ys[i]),
                end = Offset(xs[j], ys[j]),
                strokeWidth = core * 5.2f * (1f - 0.4f * u),
                cap = StrokeCap.Round,
                blendMode = BlendMode.Plus,
            )
        }
        i += 2
    }
    // The inner glow, closer round the tube.
    i = 0
    while (i < PIECES) {
        val j = minOf(i + 2, PIECES)
        val u = (i + 1) / PIECES.toFloat()
        val alpha = ((1f - u).pow(1.3f) * strength * 0.30f).coerceIn(0f, 1f)
        if (alpha > 0.01f) {
            drawLine(
                color = palette(colourAt + u * SPREAD).copy(alpha = alpha),
                start = Offset(xs[i], ys[i]),
                end = Offset(xs[j], ys[j]),
                strokeWidth = core * 2.6f * (1f - 0.4f * u),
                cap = StrokeCap.Round,
                blendMode = BlendMode.Plus,
            )
        }
        i += 2
    }
    // The tube: every piece its own colour from the palette, thinning to the tail.
    for (k in 0 until PIECES) {
        val u = (k + 0.5f) / PIECES
        val alpha = ((1f - u).pow(1.5f) * strength).coerceIn(0f, 1f)
        if (alpha < 0.02f) continue
        drawLine(
            color = palette(colourAt + u * SPREAD).copy(alpha = alpha),
            start = Offset(xs[k], ys[k]),
            end = Offset(xs[k + 1], ys[k + 1]),
            strokeWidth = core * (1f - 0.5f * u),
            cap = StrokeCap.Round,
        )
    }
    // Its hot centre, nearly white, along the part of the tube nearest the head.
    val hot = PIECES * 6 / 10
    for (k in 0 until hot) {
        val u = (k + 0.5f) / PIECES
        val alpha = ((1f - u / 0.6f).pow(1.2f) * strength * 0.85f).coerceIn(0f, 1f)
        if (alpha < 0.02f) continue
        drawLine(
            color = lerp(palette(colourAt + u * SPREAD), Color.White, 0.7f).copy(alpha = alpha),
            start = Offset(xs[k], ys[k]),
            end = Offset(xs[k + 1], ys[k + 1]),
            strokeWidth = core * 0.42f,
            cap = StrokeCap.Round,
        )
    }

    // The head: a small flare of its own, and a point of white at its middle.
    val flare = core * 5.5f
    val tip = Offset(xs[0], ys[0])
    val colour = palette(colourAt)
    drawCircle(
        brush = Brush.radialGradient(
            0f to Color.White.copy(alpha = (0.85f * strength).coerceIn(0f, 1f)),
            0.28f to colour.copy(alpha = (0.55f * strength).coerceIn(0f, 1f)),
            1f to Color.Transparent,
            center = tip,
            radius = flare,
        ),
        radius = flare,
        center = tip,
        blendMode = BlendMode.Plus,
    )
    drawCircle(
        color = Color.White.copy(alpha = (0.95f * strength).coerceIn(0f, 1f)),
        radius = core * 0.8f,
        center = tip,
    )
}

/**
 * A colour from a ring of colours, [t] being how far round it is (1 is the
 * start again): blue, violet, pink, amber, green, cyan, blue.
 */
private fun palette(t: Float): Color {
    val x = (((t % 1f) + 1f) % 1f) * (PALETTE.size - 1)
    val i = x.toInt().coerceAtMost(PALETTE.size - 2)
    return lerp(PALETTE[i], PALETTE[i + 1], x - i)
}

private val PALETTE = listOf(
    Color(0xFF4285F4), // blue
    Color(0xFF9B6BFF), // violet
    Color(0xFFFF4D8D), // pink
    Color(0xFFFFB02E), // amber
    Color(0xFF34D27B), // green
    Color(0xFF22D3EE), // cyan
    Color(0xFF4285F4), // blue again: the ring closes
)

/** The tube's own thickness: thin. Everything else is a multiple of it. */
private val CORE = 1.5.dp

/** Pieces a light is laid down in: close enough to read as one unbroken curve. */
private const val PIECES = 48

/** How much of the palette one light shows along its length. */
private const val SPREAD = 0.55f

/** Laps a second: the floor, what the level adds, and what a beat adds on top. */
private const val BASE_LAPS = 0.45f
private const val LEVEL_LAPS = 0.90f
private const val KICK_LAPS = 1.80f

/** Runs of the palette a second, the same way. */
private const val BASE_DRIFT = 0.22f
private const val LEVEL_DRIFT = 0.40f
private const val KICK_DRIFT = 0.80f
